import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import ModalWithForm from "../ModalWithForm/ModalWithForm";

function LoginModal({ isOpen, onClose, onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    // later: validate, call backend, etc.
    if (onLogin) {
      onLogin();
    }

    onClose();
    navigate("/profile");
  };

  return (
    <ModalWithForm
      name="login"
      title="Welcome Back!"
      isOpen={isOpen}
      onClose={onClose}
      onSubmit={handleSubmit}
      submitText="Log In"
    >
      <div className="form__field">
        <label htmlFor="login-email">Email</label>
        <input
          id="login-email"
          className="form__input"
          type="email"
          placeholder="you@dogmail.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>

      <div className="form__field">
        <label htmlFor="login-password">Password</label>
        <input
          id="login-password"
          className="form__input"
          type="password"
          placeholder="••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
    </ModalWithForm>
  );
}

export default LoginModal;
