import React, { useState } from "react";
import EditProfileModal from "../EditProfileModal/EditProfileModal";
import ImageModal from "../ImageModal/ImageModal";
import "./Profile.css";

function Profile() {
  const [showEdit, setShowEdit] = useState(false);
  const [showImage, setShowImage] = useState(false);

  const [name, setName] = useState("Your Name");
  const [bio, setBio] = useState("Dog lover & adventure buddy!");
  const [location, setLocation] = useState("Colorado, USA");
  const [profilePic, setProfilePic] = useState("https://placedog.net/500?id=1");

  const [gallery] = useState([
    "https://placedog.net/400?id=2",
    "https://placedog.net/400?id=3",
    "https://placedog.net/400?id=4",
  ]);

  const handleSaveProfile = ({ name, bio, location, profilePic }) => {
    setName(name);
    setBio(bio);
    setLocation(location);
    setProfilePic(profilePic);
    setShowEdit(false);
  };

  return (
    <div className="profile">
      <div className="profile__header">
        <div className="profile__avatar-container">
          <img
            src={profilePic}
            alt="Profile"
            className="profile__avatar"
            onClick={() => setShowImage(true)}
          />
        </div>

        <div className="profile__info">
          <h1 className="profile__name">{name}</h1>
          <p className="profile__bio">{bio}</p>
          <p className="profile__location">{location}</p>
          <button
            className="profile__edit-button"
            onClick={() => setShowEdit(true)}
          >
            Edit Profile
          </button>
        </div>
      </div>

      <section className="profile__gallery">
        <h2 className="profile__section-title">Photo Gallery</h2>
        <div className="profile__gallery-grid">
          {gallery.map((img, index) => (
            <img
              key={index}
              src={img}
              alt={`Gallery ${index + 1}`}
              className="profile__gallery-img"
            />
          ))}
        </div>
      </section>

      <section className="profile__spotify">
        <h2 className="profile__section-title">My Dog Walk Playlist</h2>
        <div className="profile__spotify-placeholder">
          Spotify integration coming soon!
        </div>
      </section>

      {/* Edit Profile Modal */}
      <EditProfileModal
        isOpen={showEdit}
        onClose={() => setShowEdit(false)}
        onSave={handleSaveProfile}
        name={name}
        bio={bio}
        location={location}
        profilePic={profilePic}
      />

      {/* Image Viewer Modal */}
      <ImageModal
        isOpen={showImage}
        onClose={() => setShowImage(false)}
        src={profilePic}
        alt={`${name}'s profile`}
      />
    </div>
  );
}

export default Profile;
